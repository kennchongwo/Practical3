package com.bitcomm.practical.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

@Entity
public class Theme {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	// @Column(unique = true)
	@NotEmpty(message = "Theme Name cannot be empty or null")
	@Column(length = 200)
	private String themeName;
	
	@OneToMany(mappedBy = "theme", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.EAGER)
	private List<ProjectThemes> projectThemes = new ArrayList<>();

	
	public Theme() {
		
	}
	
	
	public Theme(Long id, @NotEmpty(message = "Theme Name cannot be empty or null") String themeName,
			List<ProjectThemes> projectThemes) {
		super();
		this.id = id;
		this.themeName = themeName;
		this.projectThemes = projectThemes;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getThemeName() {
		return themeName;
	}

	public void setThemeName(String themeName) {
		this.themeName = themeName;
	}

	public List<ProjectThemes> getProjectThemes() {
		return projectThemes;
	}

	public void setProjectThemes(List<ProjectThemes> projectThemes) {
		this.projectThemes = projectThemes;
	}
	
	
	
}
