package com.bitcomm.practical.impl;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bitcomm.practical.model.PAASCode;

public interface PAASCodeRepo extends JpaRepository<PAASCode, Long>{

}
