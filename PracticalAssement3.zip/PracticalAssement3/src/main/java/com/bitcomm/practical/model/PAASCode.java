package com.bitcomm.practical.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class PAASCode {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	//@Column(unique = true)
	@NotEmpty(message = "Project Name cannot be empty or null")	
	@Column(length = 200)
	private String paascodeName;
	
	@JsonIgnore
	@OneToMany(mappedBy = "paascode", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.EAGER)
	private List<Project> projects = new ArrayList<>();
	
	public PAASCode() {
		
	}
	

	public PAASCode(Long id, @NotEmpty(message = "Project Name cannot be empty or null") String paascodeName,
			List<Project> projects) {
		super();
		this.id = id;
		this.paascodeName = paascodeName;
		this.projects = projects;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPaascodeName() {
		return paascodeName;
	}

	public void setPaascodeName(String paascodeName) {
		this.paascodeName = paascodeName;
	}

	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}
	
}
