package com.bitcomm.practical.Resources;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bitcomm.practical.impl.FundRepo;
import com.bitcomm.practical.impl.LeadOrgUnitRepo;
import com.bitcomm.practical.impl.PAASCodeRepo;
import com.bitcomm.practical.impl.ProjectsRepoDb;
import com.bitcomm.practical.model.Project;
import com.bitcomm.practical.model.Response;


@RestController
@RequestMapping("/api/projects")
public class ProjectsResource {
	private final ProjectsRepoDb repository;
	private final PAASCodeRepo paasDb;
	private final FundRepo fundDb;
	private final LeadOrgUnitRepo leadOrgUnitDb;
	
	
	
	public ProjectsResource(ProjectsRepoDb repository, PAASCodeRepo paasDb, FundRepo fundDb,
			LeadOrgUnitRepo leadOrgUnitDb) {
		super();
		this.repository = repository;
		this.paasDb = paasDb;
		this.fundDb = fundDb;
		this.leadOrgUnitDb = leadOrgUnitDb;
	}

	@GetMapping("/list")
	public ResponseEntity<Response> getProjects() throws InterruptedException {
		
		//return repository.list(20);
		//TimeUnit.SECONDS.sleep(3);
		
		Response r = new Response();
		r.setTimeStamp(LocalDateTime.now());
		r.setData(Map.of("projects", repository.list(100)));
		r.setMessage("projects Restrieved");
		r.setStatus(HttpStatus.OK);
		r.setStatusCode(HttpStatus.OK.value());
		r.setReason("-");
		r.setDeveloperMessage("-");
		return ResponseEntity.ok(r);
	}	//
	
	@GetMapping("/all")//api/projects/all
	public ResponseEntity<Response> getAllProjects() throws InterruptedException {
		
		//return repository.list(20);
		//TimeUnit.SECONDS.sleep(3);
		
		Response r = new Response();
		r.setTimeStamp(LocalDateTime.now());
		r.setData(Map.of("projects", repository.list(100)));
		r.setMessage("projects Restrieved");
		r.setStatus(HttpStatus.OK);
		r.setStatusCode(HttpStatus.OK.value());
		r.setReason("-");
		r.setDeveloperMessage("-");
		return ResponseEntity.ok(r);
	}//api/projects/status/completed
	
	@GetMapping("/status/{id}")//api/projects/all
	public ResponseEntity<Response> getProjectsByStatus(@PathVariable("id") Long String) throws InterruptedException {
		
		//return repository.list(20);
		//TimeUnit.SECONDS.sleep(3);
		
		Response r = new Response();
		r.setTimeStamp(LocalDateTime.now());
		r.setData(Map.of("projects", repository.list(100)));
		r.setMessage("projects Restrieved");
		r.setStatus(HttpStatus.OK);
		r.setStatusCode(HttpStatus.OK.value());
		r.setReason("-");
		r.setDeveloperMessage("-");
		return ResponseEntity.ok(r);
	}
	
	@PostMapping("/save")
	public ResponseEntity<Response> saveProject(@RequestBody Project project ) {
		
		project.setStartDate(LocalDateTime.now());
		project.setEndDate(LocalDateTime.now());
		Response r = new Response();
		r.setTimeStamp(LocalDateTime.now());
		r.setData(Map.of("project", repository.create(project)));
		r.setMessage("Project Created");
		r.setStatus(HttpStatus.CREATED);
		r.setDeveloperMessage("-");
		r.setReason("-");
		r.setStatusCode(HttpStatus.CREATED.value());
		return ResponseEntity.ok(r);
	}
	
	@GetMapping("/initpage")
	public ResponseEntity<Response> InitProjectsPage() throws InterruptedException {
		
		Response r = new Response();
		r.setTimeStamp(LocalDateTime.now());
		r.setData(Map.of("projects", repository.list(100)));
		
		r.setPaasCodeDta(Map.of("paascodes", paasDb.findAll()));
		r.setLeadOrgDta(Map.of("leadorgs", leadOrgUnitDb.findAll()));
		
		r.setFundDta(Map.of("funds", fundDb.findAll()));
		
		r.setMessage("projects Restrieved");
		r.setStatus(HttpStatus.OK);
		r.setStatusCode(HttpStatus.OK.value());
		r.setReason("-");
		r.setDeveloperMessage("-");
		return ResponseEntity.ok(r);
		
	}
	
	
}
