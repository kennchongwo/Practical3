package com.bitcomm.practical.impl;

import java.util.Collection;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


import com.bitcomm.practical.model.Project;

@Service
@Transactional
public class ProjectsRepoDb {
	private ProjectRepo repo;

	public ProjectsRepoDb(ProjectRepo repo) {
		super();
		this.repo = repo;
	}
	private static final Logger log = LoggerFactory.getLogger(ProjectsRepoDb.class);

	public Collection<Project> list(int limit) {
		// TODO Auto-generated method stub
		log.info("Fetching Projects ");
		return repo.findAll(PageRequest.of(0, limit)).toList();
	}
	
	public Project create(Project project) {
		// TODO Auto-generated method stub

		log.info("Saving project: {}", project.getProjectTitle());		
		return repo.save(project);
		// return null;
	}
	
	public Collection<Project> listByStatus(String status) {
		// TODO Auto-generated method stub
		log.info("Fetching Projects ");
		return repo.findByApprovalStatus(status);
	}
}
