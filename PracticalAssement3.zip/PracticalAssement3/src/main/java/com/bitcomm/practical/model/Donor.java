package com.bitcomm.practical.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

@Entity
public class Donor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	// @Column(unique = true)
	@NotEmpty(message = "Donor Name cannot be empty or null")
	@Column(length = 200)
	private String donorName;
	
	@OneToMany(mappedBy = "donor", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.EAGER)
	private List<ProjectDonors> projectDonors = new ArrayList<>();

	public Donor() {
		
	}
	
	
	public Donor(Long id, @NotEmpty(message = "Donor Name cannot be empty or null") String donorName,
			List<ProjectDonors> projectDonors) {
		super();
		this.id = id;
		this.donorName = donorName;
		this.projectDonors = projectDonors;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDonorName() {
		return donorName;
	}

	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}

	public List<ProjectDonors> getProjectDonors() {
		return projectDonors;
	}

	public void setProjectDonors(List<ProjectDonors> projectDonors) {
		this.projectDonors = projectDonors;
	}
	
	
}
