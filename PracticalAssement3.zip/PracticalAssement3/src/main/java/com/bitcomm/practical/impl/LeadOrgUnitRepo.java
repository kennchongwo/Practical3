package com.bitcomm.practical.impl;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bitcomm.practical.model.LeadOrgUnit;

public interface LeadOrgUnitRepo extends JpaRepository<LeadOrgUnit, Long>{

}
