package com.bitcomm.practical.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

@Entity
public class Country {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	// @Column(unique = true)
	@NotEmpty(message = "Country Name cannot be empty or null")
	@Column(length = 50)
	private String countryName;
	
	@OneToMany(mappedBy = "country", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.EAGER)
	private List<ProjectCountries> projectCountries = new ArrayList<>();

	public Country() {
		
	}
	
	
	public Country(Long id, @NotEmpty(message = "Country Name cannot be empty or null") String countryName,
			List<ProjectCountries> projectCountries) {
		super();
		this.id = id;
		this.countryName = countryName;
		this.projectCountries = projectCountries;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public List<ProjectCountries> getProjectCountries() {
		return projectCountries;
	}

	public void setProjectCountries(List<ProjectCountries> projectCountries) {
		this.projectCountries = projectCountries;
	}
	
	
	
}
