package com.bitcomm.practical.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	// @Column(unique = true)
	@NotEmpty(message = "Project Name cannot be empty or null")
	@Column(length = 200)
	private String projectTitle;

	//@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "paascodeId", nullable = false)
	private PAASCode paascode;
	
	//@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "fundId", nullable = false)
	private Fund fund;	
	
	private double pagValue;
	
	@Column(length = 200)
	private String approvalStatus;
	
	@Column(name = "start_date", columnDefinition = "TIMESTAMP")
	private LocalDateTime startDate;
	
	@Column(name = "end_date", columnDefinition = "TIMESTAMP")
	private LocalDateTime endDate;
	
	@JsonIgnore
	@OneToMany(mappedBy = "project", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.LAZY)
	private List<ProjectCountries> projectCountries = new ArrayList<>();
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "LeadOrgUnitId", nullable = false)
	private LeadOrgUnit leadOrgUnit;	
	@JsonIgnore
	@OneToMany(mappedBy = "project", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.LAZY)
	private List<ProjectThemes> projectThemes = new ArrayList<>();
	@JsonIgnore
	@OneToMany(mappedBy = "project", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.LAZY)
	private List<ProjectDonors> projectDonors = new ArrayList<>();
	
	private double totalExpenditure;
	private double totalContribution;
	private double totalPsc;
	
	public Project() {
		
	}
	
	
	
	public Project(Long id, @NotEmpty(message = "Project Name cannot be empty or null") String projectTitle,
			PAASCode paascode, Fund fund, double pagValue, String approvalStatus, LocalDateTime startDate,
			LocalDateTime endDate, List<ProjectCountries> projectCountries, LeadOrgUnit leadOrgUnit,
			List<ProjectThemes> projectThemes, List<ProjectDonors> projectDonors, double totalExpenditure, double totalContribution,
			double totalPsc) {
		super();
		this.id = id;
		this.projectTitle = projectTitle;
		this.paascode = paascode;
		this.fund = fund;
		this.pagValue = pagValue;
		this.approvalStatus = approvalStatus;
		this.startDate = startDate;
		this.endDate = endDate;
		this.projectCountries = projectCountries;
		this.leadOrgUnit = leadOrgUnit;
		this.projectThemes = projectThemes;
		this.projectDonors = projectDonors;
		this.totalExpenditure = totalExpenditure;
		this.totalContribution = totalContribution;
		this.totalPsc = totalPsc;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProjectTitle() {
		return projectTitle;
	}
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	public PAASCode getPaascode() {
		return paascode;
	}
	public void setPaascode(PAASCode paascode) {
		this.paascode = paascode;
	}
	public Fund getFund() {
		return fund;
	}
	public void setFund(Fund fund) {
		this.fund = fund;
	}
	public double getPagValue() {
		return pagValue;
	}
	public void setPagValue(double pagValue) {
		this.pagValue = pagValue;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public LocalDateTime getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}
	public LocalDateTime getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}
	public List<ProjectCountries> getProjectCountries() {
		return projectCountries;
	}
	public void setProjectCountries(List<ProjectCountries> projectCountries) {
		this.projectCountries = projectCountries;
	}
	public LeadOrgUnit getLeadOrgUnit() {
		return leadOrgUnit;
	}
	public void setLeadOrgUnit(LeadOrgUnit leadOrgUnit) {
		this.leadOrgUnit = leadOrgUnit;
	}
	public List<ProjectThemes> getProjectThemes() {
		return projectThemes;
	}
	public void setProjectThemes(List<ProjectThemes> projectThemes) {
		this.projectThemes = projectThemes;
	}
	public List<ProjectDonors> getProjectDonors() {
		return projectDonors;
	}
	public void setDonors(List<ProjectDonors> projectDonors) {
		this.projectDonors = projectDonors;
	}
	public double getTotalExpenditure() {
		return totalExpenditure;
	}
	public void setTotalExpenditure(double totalExpenditure) {
		this.totalExpenditure = totalExpenditure;
	}
	public double getTotalContribution() {
		return totalContribution;
	}
	public void setTotalContribution(double totalContribution) {
		this.totalContribution = totalContribution;
	}
	public double getTotalPsc() {
		return totalPsc;
	}
	public void setTotalPsc(double totalPsc) {
		this.totalPsc = totalPsc;
	}
	
	
}
