package com.bitcomm.practical.impl;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bitcomm.practical.model.Fund;

public interface FundRepo extends JpaRepository<Fund, Long>{

}
