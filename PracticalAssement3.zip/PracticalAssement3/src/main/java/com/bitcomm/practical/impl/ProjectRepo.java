package com.bitcomm.practical.impl;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bitcomm.practical.model.Project;

public interface ProjectRepo extends JpaRepository<Project, Long>{
Collection<Project> findByApprovalStatus(String approvalStatus);
}
